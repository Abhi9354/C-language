/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;
void printarray(int arr[],int size)
{
    for(int i=0;i<size;i++){
        cout<<arr[i]<<" ";
        
    }
    cout<<endl;
}
int main()
{
   int first[15]={1,2,3,4,5,5,6,7,7,88,};
   cout<<"printing the first array:"<<endl;
   printarray(first,15);
   
   int second[5]={0};
   cout<<"printing the second array:"<<endl;
   printarray(second,5);
   int third[8]={4,5,7,43,2,5};
   cout<<"printing the third array:"<<endl;
   printarray(third,8);
   
    return 0;
}