#include <stdio.h>
int main(){
    
    int a = 5 ;
    float b =(float)60/7;
    printf("the value of b is %f\n",b);
    return 0;
}