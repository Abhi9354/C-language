
#include <stdio.h>
void swap(int*a){
    *a=345;
}

int main()
{
   int a=34,b=45;
   printf("the value of a is %d\n",a);
   swap(&a);
   printf("the value of a is now %d\n",a);
   

    return 0;
}
