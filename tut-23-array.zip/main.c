#include <stdio.h>
/*int main(){
    int marks[4];
 
    for(int i=0;i<4;i++){
        printf("enter the value of %d element of the array\n",i);
        scanf("%d",&marks[i]);
    }
        for(int i=0;i<4;i++){
            printf ("the value of %d of an array is %d\n",i,marks[i]);
        }*/

int
main ()
{

  int marks[2][4];
  for (int i = 0; i < 2; i++)
    {

      for (int j = 0; j < 4; j++)
	{
	  printf ("the mtrix of an array\n");
	  scanf ("%d", &marks[i][j]);


	}

    }
  for (int i = 0; i < 2; i++)
    {

      for (int j = 0; j < 4; j++)
	{
	  printf ("%d\t\t", marks[i][j]);
	}

      printf ("\n");

    }
  return 0;
}
