#include <stdio.h>
int main(){
    float a=6.444;
    printf("%-8.2f",a);
    return 0;
}