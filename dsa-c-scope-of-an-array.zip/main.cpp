
#include <iostream>

using namespace std;
void update (int arr[],int n){
    arr[3]=120;
    for(int i =0 ;i<5;i++){
        cout<<arr[i]<<",";
    }cout<<endl;
}

int main(){
    int arr[]={2,5,5,6,6};
    for (int i=0;i<5;i++){
        cout<<arr[i]<<" ,";
    }cout<<endl;
    update(arr,5);
    
    



    return 0;
}