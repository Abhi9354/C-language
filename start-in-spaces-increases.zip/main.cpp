#include <iostream>

using namespace std;

int
main ()
{
  int num;
  cin >> num;
  int i = 1;
  while(i<=num){
      int space =i-1;
      while(space){
          cout<<" ";
          space--;
      }
  
      int j=1;
      while(j<=num-i+1){
          cout<<'*';
          j++;
          
      }
      cout<<endl;
      i++;
  
}
 

  return 0;
}
