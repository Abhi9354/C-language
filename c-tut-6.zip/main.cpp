#include<iostream>
using namespace std;
int main(){
    //types of operators are :
    //Arithmatic operators
    int a = 4;
    int b = 5;
    cout<<a+b<<endl;
    cout<<a-b<<endl;
    cout<<a*b<<endl;
    cout<<a/b<<endl;
    cout<<a%b<<endl;
    cout<<a++<<endl;
    cout<<a--<<endl;
    cout<<++a<<endl;
    cout<<--a<<endl;
    cout<<"comparison operator"<<endl;
    cout<<(a==b)<<endl;
    cout<<(a!=b)<<endl;
    cout<<(a<=b)<<endl;
    cout<<(a>=b)<<endl;
    cout<<(a<b)<<endl;
    cout<<(a>b)<<endl;
   cout<<"logical operator"<<endl;
   cout<<((a==b)&&(a!=b))<<endl;
    cout<<((a==b)||(a!=b))<<endl;
    cout<<!(a==b)<<endl;
    
    //assignment operators
    
    return 0;
    
}
