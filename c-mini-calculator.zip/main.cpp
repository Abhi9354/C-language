#include <iostream>
using namespace std;
int
main ()
{
  int a, b;
  char op;
  cout << "the value of a" << endl;
  cin >> a;
  cout << "the value of b" << endl;
  cin >> b;
  cout << "the operation to be performed" << endl;
  cin >> op;


  switch (op)
    {
    case '+':
      cout << (a + b);
      break;
    case '*':
      cout << (a * b);
      break;
    case '%':
      cout << (a % b);
      break;
    case '/':
      cout << (a / b);
      break;
    case '-':
      cout << (a - b);
      break;
    default:
      cout << "error";



    }
  return 0;
}
