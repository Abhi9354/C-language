#include <iostream>
using namespace std;
int main(){
    int num;
    cin>>num;
    int i=2;
    while(i<num-1){
        if(num%i!=0){
            cout<<"prime num";
            break;
            
        
        }
        else{
            cout<<"not prime no";
            break;
        }
    }
    return 0;
}