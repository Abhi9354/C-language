
#include <stdio.h>

int main()
{
    int arr[]= {31,56,35,36,37,36};
    printf("the value at 3rd position at array is %d\n",arr[3]);
   
   
    printf("the address of first  element of an array is %p\n",&arr[0]);
    printf("the address of second element of an array is %p\n",&arr[1]);
    printf("the address of second element of an array is %p\n",arr+1);
    
     
    printf("the value of first  element of an array is %d\n",*(&arr[0]));
    
    printf("the value of second element of an array is %p\n",&arr);
    return 0;
}
