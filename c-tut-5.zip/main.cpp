# include<iostream>
using namespace std;
int main(){
    int num1 ,num2 ;
    cout<<"enter the value of num1:\n"; /* << is called insertion operator*/
    cin>>num1; /*this is the extraction operator*/
    cout<<"enter the value of num2:\n"; /* << is called insertion operator*/
    cin>>num2; /*this is the extraction operator*/
    cout<<"the sum is "<<num1+num2;
 return 0;   
}