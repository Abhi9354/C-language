#include <iostream>

using namespace std;

int main()
{
    int num;
    cin>>num;
    int i = 1;
   char start ='A';
    while(i<=num){
        int j=1;
        while(j<=i){
       
            cout<<start;
       start++;
            j++;
            
        }
        cout<<endl;
        i++;
    }
    


    return 0;
}