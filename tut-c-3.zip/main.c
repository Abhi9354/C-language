#include <stdio.h>
int main (int arge , char const * argv[])
{printf("hello world");
return 0;}
