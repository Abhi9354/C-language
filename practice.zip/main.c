#include <stdio.h>
int main(){
    
    
    char status[40];
    char pass;
    char fail;
    
    
    printf("enter your age\n");
    scanf("%s",status);
    
    
    if(status=pass)  {
        printf("you can vote");
    }
    else if(status=fail) { 
        printf("u can vote only kid");
    }
    else {
        printf("u cannot vote");
    }
    return 0;
}
