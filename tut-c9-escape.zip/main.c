#include <stdio.h>
int main(){
    
    printf("\t backslash is my \t cup of tea ");
    
    
    return 0;
}