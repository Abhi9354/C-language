
#include <iostream>

using namespace std;

int main()
{
   int n=234;
   
      
       int a=n%10;
       int b=(n/10)%10;
       int c=((n/10)/10)%10;
      
       cout<<(a*b*c)-(a+b+c);
   
  

    return 0;
}