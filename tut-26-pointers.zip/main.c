#include <stdio.h>
int main(){
    int a = 76;
    int*ptr2 = NULL;
    int *ptra=&a;
    printf("the address of pointer is %p\n",&ptra);
    printf("the address of pointer is %p\n",&a);
    printf("the address of pointer is %p\n",ptra);
    printf("the value  of pointer is %d\n",*ptra);
    printf("the value  of pointer is %d\n",a);
    printf("the address of GARBAGE IS %p",NULL);
    return 0;
}
