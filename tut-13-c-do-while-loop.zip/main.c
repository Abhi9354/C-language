#include<stdio.h>
int main(){
    int num = 60, index = 6 ;
    printf("enter the number\n");
    
    do{
        printf("%d\n",index);
        index=index+6;
        
    }while(index<num);

    
    
    
    return 0;
    
}