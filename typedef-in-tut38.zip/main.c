
#include <stdio.h>
#include <string.h>
//typedef struct string{
//    int id;
//    int marks;
//    char fav_char;
//    char name[34];
//} std;

int main()
{
//// int *a, b;
   // typedef int* intPointer;
   // intPointer a, b;
   // int c = 89;
   // a = &c;
   // b = &c;
    typedef int* intPointer;
    int a=90;
    int* c = &a;
 
    printf("%d",&a);
   // std harry,ravi,subham;
   // harry.id=1;
   // ravi.marks=5;
   // subham.fav_char='y';
   // printf("the percentage got by ravi is %d\n",ravi.marks);
 
    return 0;
}
