#include <stdio.h>
int main(){
    
    
    int age ;
    printf("enter your age\n");
    scanf("%d",&age);
    printf("u entered texted %d as your age\n",age);
    
    if(age>=18)  {
        printf("you can vote");
    }
    else if(age>10) { 
        printf("u can vote only kid");
    }
    else {
        printf("u cannot vote");
    }
    return 0;
}