# include<stdio.h>
int main(){
    int a=0;
    int b=1;
printf("a+b=%d",a&b);
    return 0;
    
}
