
#include <stdio.h>
/*int func1(int array[]){
    for(int i=0;i<4;i++){
        printf("the value at %d is %d\n",i,array[i]);
    }
    array[0]=343;
}

int main()
{
    int arr[]={23,25,29,27};
    
    func1(arr);
    printf("the value of first element is %d",arr[0]); 
    return 0;
}*/
void func2(int*ptr){
    for(int i=0;i<4;i++){
        printf("the value at %d is %d\n",i,*(ptr+i));
    } 
    *(ptr+2)=3456;
}




int main()
{
    int arr[]={23,25,29,27};
    
    func2(arr);
    func2(arr);
   
    return 0;
}
