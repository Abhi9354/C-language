# include<stdio.h>

int main()
{
    int a,b;
    
    scanf("%d",&a);
        scanf("%d",&b);
        printf("the sum of a and b %d",a+b);
        return 0;


}