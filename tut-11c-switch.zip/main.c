#include <stdio.h>
int
main ()
{
  int a;

  printf ("enter the condition of your subjects\n");
  scanf ("%d", &a);

  switch (a)
    {
    case 1:
      printf ("u have no back");
      break;

    case 2:
      printf ("distinction");
      break;
    default:
      printf ("uncertain");

      return 0;

    }
}
