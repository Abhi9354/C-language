#include <stdio.h>
int main(){
    int i,j;
    for(i=0,j=0;i<6,j<6;i++,j++){
        printf("%d\t %d\n",i,j);
    }
    
    
    
    return 0;
    
}
