# include <iostream>
using namespace std;

void sum(){
    int glo = 5;
    cout<<glo;
}


int main()
{

cout<<sum;


    
    return 0;
}