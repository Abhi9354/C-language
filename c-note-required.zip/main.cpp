#include <iostream>
using namespace std;
int
main ()
{
  int value = 1330;
  
cout <<"if you want to see various note"<<endl;
   cout<<"press x for 100rs"<<endl;
   cout<<"press y for 50rs"<<endl;
   cout<<"press z for 20 rs"<<endl;
   cout<<"press w for 1 rs "<<endl;
   cout<<"for total note rquired "<<endl;
   cout<<"press any key"<<endl;
   
  
char op;
cin>>op;

  switch (op)
    {
    case 'x':
      
	cout << "Note required of 100rs is " << (value / 100) << endl;
	break;
      
    case 'y':
      cout << "Note required of 50rs is " << ((value % 100) / 50) << endl;
      break;
    case 'z':
      cout << "Note required of 20rs is " << (((value % 100) % 50) /
					      20) << endl;
				break;	      
    case 'w':
      cout << "Note required of 1rs is " << ((((value % 100) % 50) % 20) /
					     1) << endl;
					     break;
		default:cout<<"the total note required is "<<(value / 100)+((value % 100) / 50)+ (((value % 100) % 50)/20)+((((value % 100) % 50) % 20) /1);
					     



    }
  return 0;
}