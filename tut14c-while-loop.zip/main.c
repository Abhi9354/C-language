#include<stdio.h>
int main(){
    int i=9;
    while(i<91)
    {
        printf("%d\n",i);
        i=i+9;
        
    }
    return 0;
}