
#include <stdio.h>

int main()

{
    int num;
    printf("enter the number 0 or 1 toget the arrangement of star\n");
    scanf("%d",&num);
   
  if(num==1){
   
    printf("*******\n******\n****\n***");
  }
  else if(num==0){
      printf("\n\n\n**\n****\n*****\n******");
  }
  else{
      printf("nothing");
  }
  
  return 0;
}
