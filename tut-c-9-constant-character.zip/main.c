
#include <stdio.h>
#define PI 3.14
int main()
{
    
    
    printf("%f",PI);

    return 0;
}
